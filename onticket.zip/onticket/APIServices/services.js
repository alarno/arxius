import { APIUrls } from "../constants/APIUrls";
import { getRequestBody } from "../constants/DriveServiceConstant";
import { Keys } from "../constants/Keys";
import { Methods } from "../constants/Methods";
import { getDataFromStorage } from "../util/storage";

export const uploadImageToGoogleDrive = async (base64) => {
  const token = await getDataFromStorage(Keys.token);
  const response = await fetch(APIUrls.uploadDrive, {
    method: Methods.post,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "multipart/related; boundary=foo_bar_baz",
    },
    body: getRequestBody(base64),
  });
  const result = await response.json();
  return result;
};

export const addRecordInSheet = async (data) => {
  const token = await getDataFromStorage(Keys.token);
  const options = {
    method: Methods.post,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(data),
  };

  const response = await fetch(APIUrls.updateSheet, options);
  const result = await response.json();
  return result;
};

export const getSheet = async () => {
  let list = [];
  const res = await fetch(APIUrls.getSheet);
  const response = await res.json();
  if (response) {
    const keys = response?.values[0];
    const data = response?.values.slice(1);
    list = data.map((arr) =>
      Object.assign({}, ...keys.map((k, i) => ({ [k.toLowerCase()]: arr[i] })))
    );
  }
  return list;
};
