import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  ActivityIndicator,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from "expo-image-manipulator";
import { Camera } from "expo-camera";
import { Feather } from "@expo/vector-icons";
import DatePicker from "react-native-datepicker";

import Input from "./Input";
import Button from "../UI/Button";
import { getFormattedDate } from "../../util/date";
import { GlobalStyles } from "../../constants/styles";
import { CommonText } from "../../constants/constants";

import { storage } from "../../config";
import {
  deleteObject,
  getDownloadURL,
  ref,
  uploadBytes,
} from "firebase/storage";
import uuid from "react-native-uuid";

function ExpenseForm({
  submitButtonLabel,
  onCancel,
  onSubmit,
  defaultValues,
  isEditing,
  navigation,
  userInfo,
}) {
  const today = new Date();
  const [showLoading, setShowLoading] = useState(false);
  const [inputs, setInputs] = useState({
    amount: {
      value: defaultValues ? defaultValues.amount.toString() : "",
      isValid: true,
    },
    date: {
      value: defaultValues
        ? getFormattedDate(defaultValues.date)
        : getFormattedDate(today),
      isValid: true,
    },
    description: {
      value: defaultValues ? defaultValues.description : "",
      isValid: true,
    },
  });
  const [image, setImage] = useState(
    defaultValues ? defaultValues.image : null
  );
  const [fileLink, setFileLink] = useState(
    defaultValues ? defaultValues.image : null
  );
  const [fileThumbnailLink, setFileThumbnailLink] = useState(
    defaultValues ? defaultValues.thumbnail : null
  );
  const [fileLinkError, setFileLinkError] = useState(false);

  function inputChangedHandler(inputIdentifier, enteredValue) {
    setInputs((curInputs) => {
      return {
        ...curInputs,
        [inputIdentifier]: { value: enteredValue, isValid: true },
      };
    });
  }

  function submitHandler() {
    const expenseData = {
      id: defaultValues ? defaultValues.id : uuid.v4(),
      amount: +inputs.amount.value,
      date: inputs.date.value,
      description: inputs.description.value,
      image: fileLink,
      thumbnail: fileThumbnailLink,
    };

    const amountIsValid = !isNaN(expenseData.amount) && expenseData.amount > 0;
    const dateIsValid = expenseData.date.toString() !== "Invalid Date";
    const descriptionIsValid =
      expenseData.description.trim().length > 0 || !isRequired;

    if (
      !amountIsValid ||
      !dateIsValid ||
      !descriptionIsValid ||
      !fileLink ||
      !fileThumbnailLink
    ) {
      // Alert.alert('Invalid input', 'Please check your input values');
      setInputs((curInputs) => {
        return {
          amount: { value: curInputs.amount.value, isValid: amountIsValid },
          date: { value: curInputs.date.value, isValid: dateIsValid },
          description: {
            value: curInputs.description.value,
            isValid: descriptionIsValid,
          },
        };
      });
      setFileLinkError(true);
      return;
    }

    onSubmit(expenseData);
  }

  async function pickImageFromGallery() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      alert("Sorry, we need camera roll permissions to make this work!");
    } else {
      // permission granted
      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
        // base64: true,
      });

      if (!result.cancelled) {
        setShowLoading(true);
        const compressedImage = await compressImage(result.assets[0].uri);
        uploadImage(compressedImage);
      }
    }
  }

  async function pickImage() {
    setFileLinkError(false);
    const { status } = await Camera.requestCameraPermissionsAsync();

    if (status !== "granted") {
      alert("Sorry, we need camera permissions to make this work!");
    } else {
      let result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: false,
        // base64: true,
        quality: 1,
      });

      if (!result.cancelled) {
        setShowLoading(true);
        const compressedImage = await compressImage(result.assets[0].uri);
        uploadImage(compressedImage);
      }
    }
  }

  async function uploadImage(compressedImage) {
    setImage(null);
    const image = compressedImage;
    if (isEditing) {
      const deleteImageRef = ref(storage, fileLink);
      deleteObject(deleteImageRef);
    }
    const fileName = image.uri.substring(image.uri.lastIndexOf("/") + 1);
    const imageRef = ref(storage, `images/${fileName}`);
    const img = await fetch(image.uri);
    const bytes = await img.blob();

    try {
      const snapshot = await uploadBytes(imageRef, bytes);
      console.log("Uploaded a blob or file!");
      const imageURL = await getDownloadURL(imageRef);
      console.log("imageURL ================ : ", imageURL);
      setFileLink(imageURL);
      setFileThumbnailLink(imageURL);
      setImage(imageURL);
      setShowLoading(false);
    } catch (error) {
      console.error("Error uploading image:", error);
      // Manejar el error aquí (por ejemplo, mostrar una alerta)
    }
  }

  const compressImage = async (uri) => {
    const compressedImage = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: 1024 } }],
      { compress: 0.6, format: ImageManipulator.SaveFormat.JPEG }
    );

    return compressedImage;
  };

  const formIsInvalid =
    !inputs.amount.isValid ||
    !inputs.date.isValid ||
    (!inputs.description.isValid && isRequired);

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <View style={styles.form}>
        <Text style={styles.title}>{CommonText.newticket}</Text>
        {/* Resta del codi... */}
        <View style={styles.inputsRow}>
          <View style={[styles.rowInput, { flex: 0.4, marginRight: 8 }]}>
            <Input
              label={CommonText.amount}
              invalid={!inputs.amount.isValid}
              textInputConfig={{
                keyboardType: "decimal-pad",
                onChangeText: inputChangedHandler.bind(this, "amount"),
                value: inputs.amount.value,
                style: { color: "black" },
              }}
            />
          </View>
          <View style={[styles.rowInput, { flex: 0.6 }]}>
            <DatePicker
              date={inputs.date.value}
              mode="date"
              placeholder="Select date"
              format="YYYY-MM-DD"
              minDate="2000-01-01"
              maxDate={today.toISOString().split("T")[0]}
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              customStyles={{
                dateIcon: {
                  position: "absolute",
                  left: 0,
                  top: 4,
                  marginLeft: 0,
                },
                dateInput: {
                  borderWidth: 0,
                  alignItems: "flex-start",
                  paddingLeft: 36,
                },
                // Pots personalitzar els estils com vulguis aquí
              }}
              onDateChange={(date) => inputChangedHandler("date", date)}
            />
          </View>
        </View>
        <View style={styles.buttonsRow}>
          <View style={[styles.buttonContainer, { marginRight: 8 }]}>
            <Button onPress={pickImage} style={styles.button}>
              <View style={styles.buttonContent}>
                <Feather
                  name="camera"
                  size={24}
                  color="white"
                  style={styles.buttonIcon}
                />
                <Text style={styles.buttonText}>
                  {CommonText.takepicturecamera}
                </Text>
              </View>
            </Button>
          </View>
          <View style={styles.buttonContainer}>
            <Button onPress={pickImageFromGallery} style={styles.button}>
              <View style={styles.buttonContent}>
                <Feather
                  name="image"
                  size={24}
                  color="white"
                  style={styles.buttonIcon}
                />
                <Text style={styles.buttonText}>
                  {CommonText.takepicturegallery}
                </Text>
              </View>
            </Button>
          </View>
        </View>
        {image ? (
          <View style={styles.imageContainer}>
            <Image source={{ uri: image }} style={styles.image} />
          </View>
        ) : showLoading ? (
          <ActivityIndicator
            style={styles.loadingIndicator}
            size="large"
            color={GlobalStyles.colors.primary500}
          />
        ) : (
          fileLinkError && (
            <Text style={styles.errorText}>{CommonText.needtotakepicture}</Text>
          )
        )}
        <Input
          label={CommonText.description}
          style={styles.descriptionInput}
          invalid={!inputs.description.isValid && isRequired}
          textInputConfig={{
            multiline: true,
            onChangeText: inputChangedHandler.bind(this, "description"),
            value: inputs.description.value,
            style: { color: "black" },
          }}
        />
        {formIsInvalid && (
          <Text style={styles.errorText}>{CommonText.invalidvalues}</Text>
        )}
        <View style={styles.buttons}>
          <Button style={styles.cancelButton} onPress={onCancel}>
            {CommonText.cancel}
          </Button>

          <Button
            style={[
              styles.submitButton,
              { backgroundColor: GlobalStyles.colors.hardblue },
            ]}
            onPress={submitHandler}
          >
            {submitButtonLabel}
          </Button>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
}

export default ExpenseForm;

const styles = StyleSheet.create({
  form: {
    flex: 1,
    backgroundColor: GlobalStyles.colors.white,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: GlobalStyles.colors.error500,
    marginBottom: 24,
    textAlign: "center",
  },
  inputsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  rowInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: GlobalStyles.colors.hardblue,
    borderRadius: 5,
    padding: 8,
  },
  buttonsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  buttonContainer: {
    flex: 1,
  },
  button: {
    backgroundColor: GlobalStyles.colors.primary500,
    padding: 12,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonContent: {
    alignItems: "center",
  },
  buttonIcon: {
    marginBottom: 8,
  },
  buttonText: {
    color: GlobalStyles.colors.white,
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  imageContainer: {
    marginBottom: 16,
    alignItems: "center",
  },
  image: {
    width: 200,
    height: 150,
    resizeMode: "contain",
    borderRadius: 5,
  },
  loadingIndicator: {
    marginVertical: 20,
  },
  errorText: {
    textAlign: "center",
    color: GlobalStyles.colors.error500,
    marginVertical: 8,
  },
  descriptionInput: {
    borderColor: GlobalStyles.colors.hardblue,
    borderWidth: 1,
    marginBottom: 16,
    padding: 8,
    borderRadius: 5,
  },
  buttons: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  cancelButton: {
    backgroundColor: GlobalStyles.colors.hardblue,
    padding: 12,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    marginRight: 8,
  },
  submitButton: {
    backgroundColor: GlobalStyles.colors.hardblue,
    padding: 12,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    marginLeft: 8,
  },
});
