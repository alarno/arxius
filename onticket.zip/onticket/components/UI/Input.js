import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { GlobalStyles } from "../../constants/styles";
import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";

function Input(props) {
  const {
    editable,
    multiline,
    numberOfLines,
    maxLength,
    onChangeText,
    value,
    inputStyle,
    placeholder,
    placeholderTextColor,
    secureTextEntry,
    keyboardType,
    autoCapitalize,
  } = props;
  const [isShowPassword, setIsShowPassword] = useState(secureTextEntry);
  return (
    <View style={styles.inputContainerStyle}>
      <TextInput
        editable={editable}
        multiline={multiline}
        numberOfLines={numberOfLines}
        maxLength={maxLength}
        placeholder={placeholder}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize}
        secureTextEntry={isShowPassword}
        placeholderTextColor={
          placeholderTextColor
            ? placeholderTextColor
            : GlobalStyles.colors.primary200
        }
        onChangeText={onChangeText}
        value={value}
        style={[styles.input, inputStyle]}
      />

      {secureTextEntry && (
        <Pressable
          onPress={() => setIsShowPassword((prev) => !prev)}
          style={styles.eyeIconButton}
        >
          <Ionicons
            name={isShowPassword ? "eye" : "eye-off"}
            size={22}
            color={GlobalStyles.colors.primary500}
          />
        </Pressable>
      )}
    </View>
  );
}
//eye-off
export default Input;

const styles = StyleSheet.create({
  inputContainerStyle: {
    height: 40,
    width: "80%",
    backgroundColor: GlobalStyles.colors.primary50,
    borderRadius: 4,
    paddingHorizontal: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 15,
  },
  input: {
    flex: 1,
  },
  eyeIconButton: {
    padding: 5,
  },
});
