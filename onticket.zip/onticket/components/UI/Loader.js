import { ActivityIndicator, StyleSheet, View, Dimensions } from "react-native";
import { GlobalStyles } from "../../constants/styles";

const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

function Loader({ isVisible }) {
  return (
    isVisible && (
      <View style={styles.container}>
        <ActivityIndicator
          size="large"
          color={GlobalStyles.colors.primary500}
        />
      </View>
    )
  );
}

export default Loader;

const styles = StyleSheet.create({
  container: {
    height: windowHeight,
    width: windowWidth,
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: GlobalStyles.colors.blackOpacity,
  },
});
