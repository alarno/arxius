import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import {
  initializeAuth,
  getReactNativePersistence,
} from "firebase/auth/react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDxnl1HHRd1oRpynY9E9Yr3TT8cEKIBNJs",
  authDomain: "onticket-e4d62.firebaseapp.com",
  databaseURL:
    "https://onticket-e4d62-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "onticket-e4d62",
  storageBucket: "onticket-e4d62.appspot.com",
  messagingSenderId: "376765932230",
  appId: "1:376765932230:web:88097b768acc143b376dc7",
  measurementId: "G-XPE3YFJ0R7",
};

export const app = initializeApp(firebaseConfig);

export const db = getDatabase(app);

export const storage = getStorage(app);

export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});
