import { API_Key, Sheet_ID, Sheet_Name } from "./constants";

export const APIUrls = {
  getUserInfo: "https://www.googleapis.com/userinfo/v2/me",
  uploadDrive:
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
  getSheet: `https://sheets.googleapis.com/v4/spreadsheets/${Sheet_ID}/values/${Sheet_Name}?valueRenderOption=FORMATTED_VALUE&key=${API_Key}`,
  updateSheet: `https://sheets.googleapis.com/v4/spreadsheets/${Sheet_ID}/values/${Sheet_Name}:append?valueInputOption=USER_ENTERED&key=${API_Key}`,
};
