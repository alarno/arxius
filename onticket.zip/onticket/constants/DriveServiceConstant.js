import { folderId } from "./constants";

export const getRequestBody = (base64) => {
  let result = [];
  let ms = Date.now();

  const requestData = {
    name: `image_${ms}.jpg`,
    mimeType: "image/jpeg",
    parents: [folderId],
  };

  result = [
    "--foo_bar_baz",
    "Content-Type: application/json; charset=UTF-8",
    "",
    JSON.stringify(requestData),
    "",
    "--foo_bar_baz",
    "Content-Type: image/jpeg",
    "Content-Transfer-Encoding: base64",
    "",
    base64,
    "",
    "--foo_bar_baz--",
  ].join("\r\n");

  return result;
};

export const getFileLink = (fileId) => {
  return `https://drive.google.com/file/d/${fileId}/view?usp=drive_link`;
};

export const getFileThumbnailLink = (fileId) => {
  return `https://drive.google.com/thumbnail?id=${fileId}`;
};