export const Keys = {
  token: "@token",
  user: "@user",
};
