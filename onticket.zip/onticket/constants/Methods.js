export const Methods = {
  post: "POST",
  get: "GET",
};
