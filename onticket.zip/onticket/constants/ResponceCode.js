export const ResponceCode = {
  success: "success",
};
