// Google Services Client IDs

export const clientIds = {
  androidClientId:
    "773617262094-25ta9cm3mne8evg4vh1c3lb29hsmvt7p.apps.googleusercontent.com",
  iosClientId:
    "773617262094-7l7hh1i1lnp076mjo0ediplrq5mepi11.apps.googleusercontent.com",
  expoClientId:
    "773617262094-ichpuq54v95tgh81lsqbmjs9crpgtnpl.apps.googleusercontent.com",
};

// Google Service API Key

export const API_Key = "AIzaSyDiTVSrGM6t-wGcQnP0D77lY8sYbTibY4A";

// Google Auth Scope for services

export const scopes = [
  "profile",
  "email",
  "https://www.googleapis.com/auth/drive",
  "https://www.googleapis.com/auth/spreadsheets",
];

// Test Google sheet

export const Sheet_ID = "1H9DH49ipwxlGQ5NKskBVv0SszDx3mm6z-i_gwP7q--o";
export const Sheet_Name = "onticket";

// Test Google Drive folder for uploading images

export const folderId = "1hyjPOmFBcGzf6v2-kjxG39PNu_cWnDHt";

export const CommonText = {
  add: "Afegir",
  addexpense: "Afegir despesa",
  alert_description_maxlength:
    "la descripción ha de ser menor de 500 caràcters",
  alert_description_required: "Si us plau, introdueix una descripción",
  alert_description: "Descripció",
  alert_priority_required: "Si us plau, introdueix una prioritat",
  alert_status_required: "Si us plau, introdueix un estat",
  alert_success: "Ticket creat satisfactoriament",
  alert_title_maxlength: "El títol ha de ser menor de 100 caràcters",
  alert_title_required: "Si us plau, introdueix un títol",
  alert_title: "Nou ticket",
  alertInvalidEmailAndWrongPassword: "El correu o password és incorrecte",
  alertRequest: "Hi ha hagut un problema amb la sol·licitud",
  alertRequestForEmailAndPassword: "Si us plau, introduir email i password",
  allexpenses: "Totes les despeses",
  alreadyhaveanaccount: "Ja tinc compte?",
  amount: "Import",
  cancel: "Cancel·lar",
  confirmpassword: "Confirmar password",
  createaccount: "Crear compte",
  createnew: "Crear nou compte",
  date: "Data",
  description: "Descripció",
  donthaveaccount: "No tinc compte?",
  editexpense: "Editar despesa",
  email: "Email",
  fullname: "Nom complet",
  invalidEmail: "auth/invalid-email",
  invalidvalues: "Valors invàlids, si us plau, revisa les dades introduïdes",
  last7days: "Darrers 7 dies",
  needtotakepicture: "Si us plau, triar una foto",
  newticket: "Nou ticket",
  noexpenseslasts7days: "No hi ha despeses els darrers 7 dies",
  password: "Password",
  passwordandconfirm: "Password i confirmar password no coincideixen",
  priority: "Prioritat",
  recent: "Recent",
  recentexpenses: "Despeses recents",
  status: "Estat",
  submit: "Enviar",
  takepicturecamera: "Fer foto amb la càmara",
  takepicturegallery: "Triar foto de la biblioteca",
  therewasaproblem: "Hi ha hagut un problema al crear el compte",
  title: "Títol",
  update: "Actualitzar",
  wrongPassword: "auth/wrong-password",
};
