export const GlobalStyles = {
  colors: {
    primary50: "#FFFFFF",
    primary100: "FFFFFF",
    primary200: "#a281f0",
    primary400: "#5721d4",
    primary500: "#001a8e",
    primary700: "#FFFFFF",
    primary800: "#200364",
    accent500: "#f7bc0c",
    error50: "#fcc4e4",
    error500: "#9b095c",
    gray500: "#00baf3",
    gray700: "#221c30",
    white: "#fff",
    softblue: "#00baf3",
    hardblue: "#001a8e",
    blackOpacity: "rgba(0,0,0,0.2)",
    // onticket blau fort #001a8e
    // onticket blau fluix #00baf3
  },
};
