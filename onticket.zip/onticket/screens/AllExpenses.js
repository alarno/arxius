import { useEffect, useContext } from "react";
import { db } from "../config";
import { onValue, ref } from "firebase/database";

import ExpensesOutput from "../components/ExpensesOutput/ExpensesOutput";
import { ExpensesContext } from "../store/expenses-context";
import { useIsFocused } from "@react-navigation/native";
import { getDataFromStorage } from "../util/storage";
import { Keys } from "../constants/Keys";

function AllExpenses() {
  const { expenses, setExpense } = useContext(ExpensesContext);
  const focus = useIsFocused(); // useIsFocused as shown

  useEffect(() => {
    if (focus) {
      getUserAllExpenses();
    }
  }, [focus]);

  const getUserAllExpenses = async () => {
    const userData = await getDataFromStorage(Keys.user);
    const dbRef = ref(db, userData.uid);
    setExpense([]);
    onValue(dbRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const dataArray = Object.values(data);
        setExpense(dataArray);
      }
    });
  };

  return (
    <ExpensesOutput
      expenses={expenses}
      expensesPeriod="Total"
      fallbackText="No registered expenses found!"
    />
  );
}

export default AllExpenses;
