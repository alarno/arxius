import React, { useContext, useLayoutEffect, useState } from "react";
import { StyleSheet, View } from "react-native";
import { CommonText } from "../constants/constants";

import ExpenseForm from "../components/ManageExpense/ExpenseForm";
import IconButton from "../components/UI/IconButton";
import { GlobalStyles } from "../constants/styles";
import { ExpensesContext } from "../store/expenses-context";
import Loader from "../components/UI/Loader";
import { ref, remove, set, update } from "firebase/database";
import { db } from "../config";
import { getDataFromStorage } from "../util/storage";
import { Keys } from "../constants/Keys";

function ManageExpense({ route, navigation }) {
  const [showLoading, setShowLoading] = useState(false);

  const expensesCtx = useContext(ExpensesContext);

  const editedExpenseId = route.params?.expenseId;
  const isEditing = !!editedExpenseId;

  const selectedExpense = expensesCtx.expenses.find(
    (expense) => expense.id === editedExpenseId
  );

  useLayoutEffect(() => {
    navigation.setOptions({
      title: isEditing ? CommonText.editexpense : CommonText.addexpense,
    });
  }, [navigation, isEditing]);

  async function deleteExpenseHandler() {
    const userData = await getDataFromStorage(Keys.user);
    await remove(ref(db, userData.uid + "/" + selectedExpense.id));
    navigation.goBack();
  }

  function cancelHandler() {
    navigation.goBack();
  }

  async function confirmHandler(expenseData) {
    const userData = await getDataFromStorage(Keys.user);

    setShowLoading(true);

    const data = {
      id: expenseData.id,
      date: expenseData.date,
      amount: String(expenseData.amount),
      image: expenseData.image,
      thumbnail: expenseData.thumbnail,
      description: expenseData.description,
    };

    if (isEditing) {
      try {
        await update(ref(db, userData.uid + "/" + data.id), data);
        setTimeout(() => {
          setShowLoading(false);
          navigation.goBack();
        }, 1000);
      } catch (error) {
        setShowLoading(false);
        console.log("Error : ", error);
      }
    } else {
      try {
        await set(ref(db, userData.uid + "/" + data.id), data);
        setTimeout(() => {
          setShowLoading(false);
          navigation.goBack();
        }, 1000);
      } catch (error) {
        setShowLoading(false);
        console.log("Error : ", error);
      }
    }
  }

  return (
    <View style={styles.container}>
      <ExpenseForm
        submitButtonLabel={isEditing ? CommonText.update : CommonText.add}
        onSubmit={confirmHandler}
        onCancel={cancelHandler}
        defaultValues={selectedExpense}
        navigation={navigation}
        isEditing={isEditing}
      />
      {isEditing && (
        <View style={styles.deleteContainer}>
          <IconButton
            icon="trash"
            color={GlobalStyles.colors.error500}
            size={36}
            onPress={deleteExpenseHandler}
          />
        </View>
      )}
      <Loader isVisible={showLoading} />
    </View>
  );
}

export default ManageExpense;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: GlobalStyles.colors.white,
  },
  deleteContainer: {
    marginTop: 16,
    paddingTop: 8,
    borderTopWidth: 2,
    borderTopColor: GlobalStyles.colors.primary200,
    alignItems: "center",
  },
});
