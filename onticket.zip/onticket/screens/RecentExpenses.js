import { useContext, useEffect } from "react";

import ExpensesOutput from "../components/ExpensesOutput/ExpensesOutput";
import { ExpensesContext } from "../store/expenses-context";

import { getSheet } from "../APIServices/services";
import { db } from "../config";
import { onValue, ref } from "firebase/database";
import { useIsFocused } from "@react-navigation/native";
import { getDataFromStorage } from "../util/storage";
import { Keys } from "../constants/Keys";
import { CommonText } from "../constants/constants";

function RecentExpenses() {
  const { expenses, setExpense } = useContext(ExpensesContext);
  const focus = useIsFocused(); // useIsFocused as shown

  useEffect(() => {
    if (focus) {
      getUserRecentExpense();
    }
  }, [focus]);

  const getUserRecentExpense = async () => {
    const userData = await getDataFromStorage(Keys.user);
    const dbRef = ref(db, userData.uid);
    setExpense([]);
    onValue(dbRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const dataArray = Object.values(data);
        const recentExpenses = dataArray.filter((expense) => {
          const today = new Date();
          const sevenDaysAgo = new Date();
          sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
          const expenseDate = new Date(expense.date);
          return expenseDate >= sevenDaysAgo;
        });
        setExpense(recentExpenses);
      }
    });
  };

  return (
    <ExpensesOutput
      expenses={expenses}
      expensesPeriod={CommonText.last7days}
      fallbackText={CommonText.noexpenseslasts7days}
    />
  );
}

export default RecentExpenses;
