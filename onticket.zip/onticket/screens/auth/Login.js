import React, { useState } from "react";
import { Text, View } from "react-native";
import { GlobalStyles } from "../../constants/styles";
import { StyleSheet } from "react-native";
import Input from "../../components/UI/Input";
import Button from "../../components/UI/Button";
import { CommonText } from "../../constants/constants";
import { auth } from "../../config";
import { signInWithEmailAndPassword } from "firebase/auth/react-native";

const Login = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const loginHandler = async () => {
    if (email && password) {
      try {
        await signInWithEmailAndPassword(auth, email, password);
      } catch (error) {
        console.log(" error login : ", error);
        if (
          error.code === CommonText.invalidEmail ||
          error.code === CommonText.wrongPassword
        ) {
          alert(CommonText.alertInvalidEmailAndWrongPassword);
        } else {
          alert(CommonText.alertRequest);
        }
      }
    } else {
      alert(CommonText.alertRequestForEmailAndPassword);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <Input
        value={email}
        onChangeText={(text) => setEmail(text.toLowerCase().trim())}
        placeholder="Email"
        keyboardType="email-address"
      />
      <Input
        value={password}
        onChangeText={(text) => setPassword(text.trim())}
        placeholder="Password"
        secureTextEntry
      />
      <Button
        onPress={loginHandler}
        style={styles.button}
        buttonStyle={styles.buttonStyle}
      >
        Login
      </Button>
      <View style={styles.footer}>
        <Text style={styles.accountText}>
          {CommonText.donthaveaccount}{" "}
          <Text
            style={styles.signupText}
            onPress={() => navigation.navigate("Signup")}
          >
            {CommonText.createnew}
          </Text>
        </Text>
      </View>
    </View>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: GlobalStyles.colors.primary500,
  },
  title: {
    fontSize: 32,
    color: GlobalStyles.colors.softblue,
    fontWeight: "bold",
    position: "absolute",
    top: 260,
  },
  button: {
    width: "80%",
    marginHorizontal: 8,
  },
  buttonStyle: {
    height: 45,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: GlobalStyles.colors.softblue,
  },
  footer: {
    position: "absolute",
    bottom: 30,
  },
  accountText: {
    fontSize: 14,
    color: GlobalStyles.colors.white,
  },
  signupText: {
    fontSize: 15,
    color: GlobalStyles.colors.softblue,
    fontWeight: "bold",
  },
});
