import { useEffect, useContext, useState } from "react";
import { Text, View } from "react-native";
import { CommonActions, useIsFocused } from "@react-navigation/native";
import { GlobalStyles } from "../../constants/styles";
import { StyleSheet } from "react-native";
import Input from "../../components/UI/Input";
import Button from "../../components/UI/Button";
import { auth } from "../../config";
import { createUserWithEmailAndPassword } from "firebase/auth/react-native";
import { CommonText } from "../../constants/constants";

const Signup = ({ navigation }) => {
  //   const { expenses, setExpense } = useContext(ExpensesContext);
  const focus = useIsFocused(); // useIsFocused as shown

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const signupHandler = async () => {
    try {
      if (password === confirmPassword) {
        const response = await createUserWithEmailAndPassword(
          auth,
          email,
          password,
          fullName
        );
      } else {
        alert(CommonText.passwordandconfirm);
      }
    } catch (e) {
      alert(CommonText.therewasaproblem);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Signup</Text>
      <Input
        value={fullName}
        onChangeText={setFullName}
        placeholder={CommonText.fullname}
      />
      <Input
        value={email}
        onChangeText={(text) => setEmail(text.toLowerCase().trim())}
        placeholder="Email"
        autoCapitalize="none"
        keyboardType="email-address"
      />
      <Input
        value={password}
        onChangeText={(text) => setPassword(text.trim())}
        placeholder="Password"
        secureTextEntry
      />
      <Input
        value={confirmPassword}
        onChangeText={(text) => setConfirmPassword(text.trim())}
        placeholder={CommonText.confirmpassword}
        secureTextEntry
      />
      <Button
        onPress={() => {
          // navigation.navigate("ExpensesOverview");
          signupHandler();
        }}
        style={styles.button}
        buttonStyle={styles.buttonStyle}
      >
        {CommonText.createaccount}
      </Button>
      <View style={styles.footer}>
        <Text style={styles.accountText}>
          {CommonText.alreadyhaveaccount}{" "}
          <Text style={styles.signupText} onPress={() => navigation.goBack()}>
            Login
          </Text>
        </Text>
      </View>
    </View>
  );
};

export default Signup;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: GlobalStyles.colors.primary500,
  },
  title: {
    fontSize: 32,
    color: GlobalStyles.colors.softblue,
    fontWeight: "bold",
    position: "absolute",
    top: 200,
  },
  button: {
    width: "80%",
    marginHorizontal: 8,
  },
  buttonStyle: {
    height: 45,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: GlobalStyles.colors.softblue,
  },
  footer: {
    position: "absolute",
    bottom: 30,
  },
  accountText: {
    fontSize: 14,
    color: GlobalStyles.colors.white,
  },
  signupText: {
    fontSize: 15,
    color: GlobalStyles.colors.white,
    fontWeight: "bold",
  },
});
