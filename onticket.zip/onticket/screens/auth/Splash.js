import React, { useEffect } from "react";
import { Text, View } from "react-native";
import { GlobalStyles } from "../../constants/styles";
import { StyleSheet } from "react-native";
import { auth } from "../../config";
import { StackActions } from "@react-navigation/native";
import { onAuthStateChanged } from "firebase/auth/react-native";
import { storeDataToStorage } from "../../util/storage";
import { Keys } from "../../constants/Keys";

const Splash = ({ navigation }) => {
  useEffect(() => {
    onAuthStateChanged(auth, (user) => {
      setTimeout(() => {
        if (user) {
          storeDataToStorage(Keys.user, user);
          navigation.dispatch(StackActions.replace("ExpensesOverview"));
        } else {
          navigation.dispatch(StackActions.replace("Login"));
        }
      }, 3000);
    });
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Onticket</Text>
    </View>
  );
};

export default Splash;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: GlobalStyles.colors.primary500,
  },
  title: {
    fontSize: 32,
    color: GlobalStyles.colors.white,
    fontWeight: "bold",
  },
});
