export function getFormattedDate(inputDate) {
  const date = new Date(inputDate);

  // Extract the year, month, and day from the Date object
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  // Format the date as "YYYY-MM-DD"
  const formattedDate = `${year}-${month}-${day}`;
  return formattedDate;
}

export function getDateMinusDays(date, days) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() - days);
}

export const generateRandomId = () => {
  const timestamp = new Date().getTime();
  const random = Math.floor(Math.random() * 100000); 
  return `${timestamp}-${random}`;
};
