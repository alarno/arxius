import AsyncStorage from "@react-native-async-storage/async-storage";

export const storeDataToStorage = async (key, value) => {
  await AsyncStorage.setItem(key, JSON.stringify(value));
};

export const getDataFromStorage = async (key) => {
  let data = await AsyncStorage.getItem(key);
  let newData = JSON.parse(data);
  return newData;
};

export const removeDataFromStorage = async (key) => {
  await AsyncStorage.removeItem(key);
};
